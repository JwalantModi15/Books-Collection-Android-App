package com.techinnovator.bookscollection

import android.content.Context
import android.media.Image
import android.media.Rating
import android.os.AsyncTask
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.widget.Toolbar
import androidx.room.Room
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.squareup.picasso.Picasso
import com.techinnovator.bookscollection.database.BookDatabase
import com.techinnovator.bookscollection.database.BookEntity
import org.json.JSONException
import org.json.JSONObject

class DescriptionActivity : AppCompatActivity() {
    lateinit var txtBookName: TextView
    lateinit var txtAuthor: TextView
    lateinit var imgBook: ImageView
    lateinit var txtPrice: TextView
    lateinit var txtRating: TextView
    lateinit var txtDesc: TextView
    lateinit var progressBarDesc: ProgressBar
    lateinit var progressLayout: RelativeLayout
    lateinit var toolbar: Toolbar

    lateinit var btnFav: Button
    var bookId: String? = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_description)

        txtBookName = findViewById(R.id.txtNameBook)
        txtAuthor = findViewById(R.id.txtAuthor)
        imgBook = findViewById(R.id.imgBook)
        txtPrice = findViewById(R.id.txtPrice)
        txtRating = findViewById(R.id.txtRating)
        txtDesc = findViewById(R.id.txtDesc)
        btnFav = findViewById(R.id.btnFav)
        toolbar = findViewById(R.id.toolBarDesc)
//        progressBarDesc = findViewById(R.id.progressBarDesc)
//        progressLayout = findViewById(R.id.progressLayout)

        setSupportActionBar(toolbar)
        supportActionBar?.title = "Book Details"

        if(intent!=null){
            bookId = intent.getStringExtra("book_id")
            println(bookId)
        }
        var queue = Volley.newRequestQueue(this)
        val url = "http://13.235.250.119/v1/book/get_book/"

        val obj = JSONObject()

        obj.put("book_id", bookId)

        val jsonObjectRequest = object : JsonObjectRequest(Method.POST, url, obj, Response.Listener {

            try {
                var success = it.getBoolean("success")
                if(success){
                    val bookObj = it.getJSONObject("book_data")
                    txtBookName.text = bookObj.getString("name")
                    txtAuthor.text = bookObj.getString("author")
                    txtPrice.text = bookObj.getString("price")
                    txtRating.text = bookObj.getString("rating")
                    Picasso.get().load(bookObj.getString("image")).error(R.drawable.default_book_cover).into(imgBook)
                    txtDesc.text = bookObj.getString("description")

                    println(txtRating.text)

                    val bookEntity = BookEntity(bookId?.toInt() as Int, txtBookName.text.toString(), txtAuthor.text as String, txtPrice.text.toString(), txtRating.text.toString(), txtDesc.text.toString(), bookObj.getString("image"))

                    val isFav = DBAsyncTask(applicationContext, bookEntity, 1).execute().get()

                    if(isFav){
                        btnFav.text = "Remove from Favourites"
                    }
                    else{
                        btnFav.text = "Add to Favourites"
                    }

                    btnFav.setOnClickListener {
                        if(!DBAsyncTask(applicationContext, bookEntity, 1).execute().get()){
                            val add = DBAsyncTask(applicationContext, bookEntity, 2).execute().get()
                            if(add){
                                Toast.makeText(this, "Book added to Favourites", Toast.LENGTH_SHORT).show()
                                btnFav.text = "Remove from Favourites"
                            }
                        }
                        else{
                            val add = DBAsyncTask(applicationContext, bookEntity, 3).execute().get()
                            if(add){
                                Toast.makeText(this, "Book remove from Favourites", Toast.LENGTH_SHORT).show()
                                btnFav.text = "Add to Favourites"
                            }
                        }
                    }
                }
                else{
                    Toast.makeText(this, "Internet Error", Toast.LENGTH_SHORT).show()
                }
            }
            catch (e:JSONException){
                Toast.makeText(this, "Error", Toast.LENGTH_SHORT).show()
            }

        }, Response.ErrorListener {


        }){
            override fun getHeaders(): MutableMap<String, String> {
                val headers = HashMap<String, String>()
                headers["Context-type"] = "application/json"
                headers["token"] = "43629e8a360298"
                return headers
            }
        }
        queue.add(jsonObjectRequest)
    }

    class DBAsyncTask(val context: Context, val bookEntity: BookEntity, val mode: Int): AsyncTask<Void, Void, Boolean>(){

        val db = Room.databaseBuilder(context, BookDatabase::class.java, "book-db").build()

        override fun doInBackground(vararg params: Void?): Boolean {

            when(mode){
                1-> {
                    val book = db.bookDao().getBookById(bookEntity.book_id.toString())
                    db.close()
                    return book!=null
                }

                2-> {
                    db.bookDao().insertBook(bookEntity)
                    db.close()
                    return true
                }

                3->{
                    db.bookDao().deleteBook(bookEntity)
                    db.close()
                    return true
                }
            }

            return false
        }

    }
}
package com.techinnovator.bookscollection.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View;
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.squareup.picasso.Picasso
import com.techinnovator.bookscollection.R
import com.techinnovator.bookscollection.database.BookEntity

class FavouriteRecyclerAdapter (val context: Context, val bookEntity: List<BookEntity>): RecyclerView.Adapter<FavouriteRecyclerAdapter.FavViewHolder>(){

    class FavViewHolder(view: View):RecyclerView.ViewHolder(view){
        val txtBookName: TextView = view.findViewById(R.id.txtFavBookTitle)
        val txtBookAuthor: TextView = view.findViewById(R.id.txtFavBookAuthor)
        val txtPrice: TextView = view.findViewById(R.id.txtFavBookPrice)
        val txtRating: TextView = view.findViewById(R.id.txtFavBookRating)
        val img: ImageView = view.findViewById(R.id.imgFavBookImage)
        val content: LinearLayout = view.findViewById(R.id.llFavContent)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FavViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.recycler_favourite_lists_of_items, parent, false)
        return FavViewHolder(view)
    }

    override fun getItemCount(): Int {
        return bookEntity.size
    }

    override fun onBindViewHolder(holder: FavViewHolder, position: Int) {
        val book = bookEntity[position]

        holder.txtBookName.text = book.book_name
        holder.txtBookAuthor.text = book.book_author
        holder.txtPrice.text = book.book_price
        holder.txtRating.text = book.book_rating
        Picasso.get().load(book.book_img).error(R.drawable.default_book_cover).into(holder.img)
    }

}
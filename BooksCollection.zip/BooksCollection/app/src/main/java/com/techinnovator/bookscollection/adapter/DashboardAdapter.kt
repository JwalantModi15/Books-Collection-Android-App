package com.techinnovator.bookscollection.adapter

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.recyclerview.widget.RecyclerView
import com.squareup.picasso.Picasso
import com.techinnovator.bookscollection.DescriptionActivity
import com.techinnovator.bookscollection.R
import com.techinnovator.bookscollection.model.Book

class DashboardAdapter(var context: Context, var list: ArrayList<Book>) : RecyclerView.Adapter<DashboardAdapter.DashboardViewHolder>() {

    class DashboardViewHolder(view:View) : RecyclerView.ViewHolder(view){
        var nameBook: TextView = view.findViewById(R.id.txtList)
        var nameAuthor: TextView = view.findViewById(R.id.txtName)
        var rating: TextView = view.findViewById(R.id.txtRating)
        var price: TextView = view.findViewById(R.id.txtPrice)
        var img: ImageView = view.findViewById(R.id.imgBooks)
        var relativeLayout: RelativeLayout = view.findViewById(R.id.relativeLayout)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DashboardViewHolder {
        var view = LayoutInflater.from(parent.context).inflate(R.layout.recycler_dasboard_lists_of_items, parent, false)
        return DashboardViewHolder(view)
    }

    override fun getItemCount(): Int {
        return list.size
    }

    override fun onBindViewHolder(holder: DashboardViewHolder, position: Int) {
        var book = list[position]
        holder.nameBook.text = book.bookName
        holder.nameAuthor.text = book.bookAuthor
        holder.price.text = book.bookPrice
        holder.rating.text = book.bookRating

        Picasso.get().load(book.bookImage).error(R.drawable.default_book_cover).into(holder.img)

        holder.relativeLayout.setOnClickListener{
            var intent = Intent(context, DescriptionActivity::class.java)
            intent.putExtra("book_id", book.bookId)
            context.startActivity(intent)
        }
    }
}
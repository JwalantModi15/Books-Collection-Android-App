package com.techinnovator.bookscollection.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "books")
data class BookEntity (
    @PrimaryKey val book_id: Int,
    val book_name: String,
    val book_author: String,
    val book_price: String,
    val book_rating: String,
    val book_desc: String,
    val book_img: String
)
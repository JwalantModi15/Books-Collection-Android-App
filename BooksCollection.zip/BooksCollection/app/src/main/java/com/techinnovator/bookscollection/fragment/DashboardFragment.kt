package com.techinnovator.bookscollection.fragment

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.*
import androidx.fragment.app.Fragment
import android.widget.ProgressBar
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.techinnovator.bookscollection.R
import com.techinnovator.bookscollection.adapter.DashboardAdapter
import com.techinnovator.bookscollection.model.Book
import com.techinnovator.bookscollection.util.ConnectionManager
import org.json.JSONException
import java.util.*
import kotlin.collections.HashMap

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [DashboardFragment.newInstance] factory method to
 * create an instance of this fragment.
 */
class DashboardFragment : Fragment() {
    // TODO: Rename and change types of parameters
    private var param1: String? = null
    private var param2: String? = null
    lateinit var recyclerDashboard: RecyclerView
    lateinit var linearLayoutManager: RecyclerView.LayoutManager
    lateinit var dashboardAdapter: DashboardAdapter
    lateinit var progressBar: ProgressBar

    val bookInfoList = arrayListOf<Book>()

    var comparator = Comparator<Book>{ book1, book2 ->

        if (book1.bookRating.compareTo(book2.bookRating, true) == 0){
            book1.bookName.compareTo(book2.bookName, true)
        }
        else{
            book1.bookRating.compareTo(book2.bookRating, true)
        }
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            param1 = it.getString(ARG_PARAM1)
            param2 = it.getString(ARG_PARAM2)
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        var view = inflater.inflate(R.layout.fragment_dashboard, container, false)

        setHasOptionsMenu(true) // it tells compiler that the fragment has option menu

        recyclerDashboard = view.findViewById(R.id.dashboardRecyclerView)

        linearLayoutManager = LinearLayoutManager(activity)

        progressBar = view.findViewById(R.id.progressBar)
        progressBar.visibility = View.VISIBLE

        if(!ConnectionManager().isConnect(activity as Context)){
            var dialogBox = AlertDialog.Builder(activity as Context)
            dialogBox.setTitle("Alert")
            dialogBox.setMessage("Check your internet connection")
            dialogBox.setPositiveButton("Open Settings") {text, listener ->
                val intent = Intent(Settings.ACTION_WIRELESS_SETTINGS)
                startActivity(intent)
                activity?.finish()
            }
            dialogBox.setNegativeButton("Exit"){
                text, listener ->
                ActivityCompat.finishAffinity(activity as Activity)
            }
            dialogBox.create()
            dialogBox.show()

        }
        var queue = Volley.newRequestQueue(activity as Context)

        var url = "http://13.235.250.119/v1/book/fetch_books/"

        var jsonObjectRequest = object :JsonObjectRequest(Request.Method.GET, url, null, Response.Listener {

            try {
                var isSuccess = it.getBoolean("success")
                if (isSuccess) {


                    var data = it.getJSONArray("data")
                    progressBar.visibility = View.GONE
                    for (i in 0 until data.length()) {
                        var jsonObject = data.getJSONObject(i)

                        var bookObject = Book(jsonObject.getString("book_id"), jsonObject.getString("name"), jsonObject.getString("author"),
                                jsonObject.getString("rating"), jsonObject.getString("price"), jsonObject.getString("image")
                        )
                        bookInfoList.add(bookObject)
                    }

                    dashboardAdapter = DashboardAdapter(activity as Context, bookInfoList)

                    recyclerDashboard.layoutManager = linearLayoutManager

                    recyclerDashboard.adapter = dashboardAdapter

                    recyclerDashboard.addItemDecoration(
                            DividerItemDecoration(recyclerDashboard.context, LinearLayoutManager.VERTICAL)
                    )

            } else {
                Toast.makeText(activity as Context, "Error Occurred!", Toast.LENGTH_SHORT).show()
            }
        }
            catch (e: JSONException){
                Toast.makeText(activity as Context, "Error Occurred!", Toast.LENGTH_SHORT).show()
            }

        }, Response.ErrorListener {

        }){
            override fun getHeaders(): MutableMap<String, String> {
                var headers = HashMap<String, String>()
                headers["Content-type"] = "application/json"
                headers["token"] = "43629e8a360298"
                return headers
            }
        }

        queue.add(jsonObjectRequest)

        return view
    }

    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param param1 Parameter 1.
         * @param param2 Parameter 2.
         * @return A new instance of fragment DashboardFragement.
         */
        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
                DashboardFragment().apply {
                    arguments = Bundle().apply {
                        putString(ARG_PARAM1, param1)
                        putString(ARG_PARAM2, param2)
                    }
                }
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        inflater.inflate(R.menu.dashboard_sort, menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        var id = item.itemId

        if (id == R.id.sort){
            Collections.sort(bookInfoList, comparator)
        }

        bookInfoList.reverse()

        dashboardAdapter.notifyDataSetChanged()

        return super.onOptionsItemSelected(item)
    }
}